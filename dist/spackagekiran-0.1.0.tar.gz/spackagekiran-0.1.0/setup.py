from setuptools import setup, find_packages
setup(
name='spackagekiran',
version='0.1.0',
author='Sai Kiran Majji',
author_email='kiranmajji1620@gmail.com',
description='A short description of your package',
packages=find_packages(),
classifiers=[
'Programming Language :: Python :: 3',
'License :: OSI Approved :: MIT License',
'Operating System :: OS Independent',
],
python_requires='>=3.6',
)