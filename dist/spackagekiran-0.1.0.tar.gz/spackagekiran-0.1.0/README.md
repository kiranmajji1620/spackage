`import spackagekiran`
`print(spackagekiran.add(5,6))`